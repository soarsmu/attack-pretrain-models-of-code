#include<iostream>
 #include <string>
 #include<fstream>
 #include<ostream>
 #include<vector>
 #include<algorithm>
 #include<set>
 using namespace std;
 
 #define InputOutputToFile
 
 int main(void)
 {
 #ifdef InputOutputToFile
 	
 	//cin redirection
 	std::ifstream fin("cin.txt");
 	std::streambuf *inbuf = std::cin.rdbuf(fin.rdbuf());
 
 	//cout redirection
 	std::streambuf* cout_sbuf = std::cout.rdbuf(); // save original sbuf 
 	std::ofstream   fout("cout.txt"); 
 	std::cout.rdbuf(fout.rdbuf()); // redirect 'cout' to a 'fout' 
 	//std::cout.rdbuf(cout_sbuf); // restore the original stream buffer 
 #endif
 
 	int run = 0;
 	cin>>run;
 
 	int min = 0;
 	int max = 0;
 
 	bool itrFlg = false;
 	set<int> st_rec;
 	set<int> st_all;
 	set<int>::iterator it_st_rec;
 	set<int>::iterator it_st_all;
 
 	//int count = 0;
 	int cs = 1;
 
 	while(run--)
 	{
 		st_rec.clear();
 		st_all.clear();
 		//count = 0;
 
 		if(itrFlg)
 			cout<<endl;
 		itrFlg = true;
 
 		min = 0;
 		max = 0;
 		cin>>min;
 		cin>>max;
 		
 		for(; min<=max;min++)
 		{
 			if(max<=20)
 				break;
 
 			if(min<=11)
 				min = 12;
 
 			if(min<=99)
 			{
 				int arr_1[2] = {0,0};
 				int arr_2[2] = {0,0};
 				int tmp  = 0;
 				tmp = min;
 				arr_2[1]=arr_1[1] = tmp%10;
 				tmp = tmp/10;
 				arr_2[0]=arr_1[0] = tmp%10;
 							
 				while(next_permutation(arr_2,arr_2+2))
 				{
 					if((arr_2[1] == arr_1[0]) && (arr_2[0] == arr_1[1]))
 					{
 						tmp = arr_2[0]*10 + arr_2[1];
 						it_st_all = st_all.find(tmp);
 						it_st_rec = st_rec.find(tmp);
 						if( (it_st_all == st_all.end()) && (it_st_rec == st_rec.end()) && tmp<=max)
 						{
 							//count++;
 							st_rec.insert(min);
 							st_all.insert(min);
 							st_all.insert(tmp);
 						}
 					}
 				}
 			}
 			else if(min<=999)
 			{
 				int arr_1[3] = {0,0,0};
 				int arr_2[3] = {0,0,0};
 				int tmp  = 0;
 				tmp = min;
 				arr_2[2]=arr_1[2] = tmp%10;
 				tmp = tmp/10;
 				arr_2[1]=arr_1[1] = tmp%10;
 				tmp = tmp/10;
 				arr_2[0]=arr_1[0] = tmp%10;
 				
 				while(next_permutation(arr_2,arr_2+3))
 				{
 					if( ((arr_2[0] == arr_1[2]) && (arr_2[1] == arr_1[0]) && (arr_2[2] == arr_1[1])) || ((arr_2[0] == arr_1[1]) && (arr_2[1] == arr_1[2]) && (arr_2[2] == arr_1[0])) ) 
 					{
 						tmp = arr_2[0]*100 + arr_2[1]*10 + arr_2[2];
 						it_st_all = st_all.find(tmp);
 						it_st_rec = st_rec.find(tmp);
 						if( (it_st_all == st_all.end()) && (it_st_rec == st_rec.end()) && tmp<=max && tmp>=min)
 						{
 							//count++;
 							st_rec.insert(min);
 							st_all.insert(min);
 							st_all.insert(tmp);
 						}
 					}
 				}
 			}
 
 		}/*
 		for(it_st_all = st_all.begin(); it_st_all != st_all.end(); it_st_all++)
 			cout<<*(it_st_all)<<" ";
 		cout<<endl;
 
 		for(it_st_rec = st_rec.begin(); it_st_rec != st_rec.end(); it_st_rec++)
 			cout<<*(it_st_rec)<<" ";
 		cout<<endl;
 		*/
 		cout<<"Case #"<<cs<<": "<<(int)st_rec.size();
 		cs++;
 
 	}
 
 	return 0;
 }
 
