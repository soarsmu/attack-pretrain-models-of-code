#include <iostream>
 #include<fstream>
 //#include<ostream>
 using namespace std;
 
 #define InputOutputToFile
 
 int main(void)
 {
 #ifdef InputOutputToFile
 	//cin redirection
 	std::ifstream fin("cin.txt");
 	std::streambuf *inbuf = std::cin.rdbuf(fin.rdbuf());
 
 	//cout redirection
 	std::streambuf* cout_sbuf = std::cout.rdbuf(); // save original sbuf 
 	std::ofstream   fout("cout.txt"); 
 	std::cout.rdbuf(fout.rdbuf()); // redirect 'cout' to a 'fout' 
 	//std::cout.rdbuf(cout_sbuf); // restore the original stream buffer 
 #endif
 
 	int run = 0;
 	cin>>run;
 	bool itrFlg = false;
 	int iter = 0;
 	while(run--)
 	{
 		++iter;
 		if(itrFlg)
 			cout<<endl;
 		itrFlg = true;
 		int N;
 		cin>>N;
 		int M;
 		cin>>M;
 
 		int**ptr = new int*[N];
 		for(int a=0;a<N;a++)
 			ptr[a] = new int[M];
 
 		int i,j;
 		int temp;
 		for(i=0;i<N;i++)
 		{
 			for(j=0;j<M;j++)
 			{
 				cin>>temp;
 				ptr[i][j] = temp;
 			}
 		}
 		
 		if( (N>=3 && M>3) || (N>3 && M>=3))
 		{
 			char** mover = new char*[N];
 			for(int a=0;a<(N);a++)
 				mover[a] = new char[M];
 		
 			for(i=0;i<(N);i++)
 			{
 				for(j=0;j<(M);j++)
 				{
 					mover[i][j] = 'N';
 				}
 			}
 			for(i=1;i<N-1;i++)
 			{
 				j=0;
 				while(j<(M-1))
 				{
 					if(ptr[i][j] <= ptr[i][j+1])
 						mover[i][++j] = 'Y';
 					else
 						break;
 				}
 				j=M-1;
 				while(j>0)
 				{
 					if(ptr[i][j] <= ptr[i][j-1])
 						mover[i][--j] = 'Y';
 					else
 						break;
 				}
 			}
 
 			for(j=1;j<M-1;j++)
 			{
 				i=0;
 				while(i<(N-1))
 				{
 					if(ptr[i][j] <= ptr[i+1][j])
 						mover[++i][j] = 'Y';
 					else
 						break;
 				}
 				i=N-1;
 				while(i>0)
 				{
 					if(ptr[i][j] <= ptr[i-1][j])
 						mover[--i][j] = 'Y';
 					else
 						break;
 				}
 			}
 
 			for(j=0;j<M;j++)
 				mover[0][j] = 'Y';
 
 			for(j=0;j<M;j++)
 				mover[N-1][j] = 'Y';
 
 			for(i=0;i<N;i++)
 				mover[i][0] = 'Y';
 
 			for(i=0;i<N;i++)
 				mover[i][M-1] = 'Y';
 
 			for(i=1;i<(N-1);i++)
 			{
 				bool bigl = false;
 				j=1;
 				while( (j<(M-1)) && (ptr[i][0] >= ptr[i][j]) )
 					j++;
 				if(j==(M-1))
 					bigl = true;
 				
 				if(bigl)
 				{
 					j=1;
 					while(j<(M-1))
 					{
 						if(ptr[i][0] == ptr[i][j])
 							mover[i][j]='Y';
 						j++;
 					}
 				}
 
 				bool bigr = false;
 				j=M-2;
 				while( j>0 && (ptr[i][M-1]>=ptr[i][j]))
 					j--;
 				if(j == 0)
 					bigr = true;
 
 				if(bigr)
 				{
 					j=M-2;
 					while(j>0)
 					{
 						if(ptr[i][M-1] == ptr[i][j])
 							mover[i][j]='Y';
 						j--;
 					}
 				}
 			}
 
 			for(j=1;j<(M-1);j++)
 			{
 				bool bigl = false;
 				i=1;
 				while( (i<(N-1)) && (ptr[0][j] >= ptr[i][j]) )
 					i++;
 				if(i==(N-1))
 					bigl = true;
 				
 				if(bigl)
 				{
 					i=1;
 					while(i<(N-1))
 					{
 						if(ptr[0][j] == ptr[i][j])
 							mover[i][j]='Y';
 						i++;
 					}
 				}
 
 				bool bigr = false;
 				i=N-2;
 				while( i>0 && (ptr[N-1][j]>=ptr[i][j]))
 					i--;
 				if(i == 0)
 					bigr = true;
 
 				if(bigr)
 				{
 					i=N-2;
 					while(i>0)
 					{
 						if(ptr[N-1][j] == ptr[i][j])
 							mover[i][j]='Y';
 						i--;
 					}
 				}
 			}
 
 
 
 			//logs
 			/*for(i=0;i<(N);i++)
 			{
 				for(j=0;j<(M);j++)
 				{
 					cout<<mover[i][j]<<" ";
 				}
 				cout<<endl;
 			}*/
 
 			bool Nflag = false;
 
 			for(i=0;i<(N);i++)
 			{
 				for(j=0;j<(M);j++)
 				{
 					if(mover[i][j] == 'N')
 					{
 						cout<<"Case #"<<iter<<": NO";
 						Nflag = true;
 						break;
 					}
 				}
 				if(Nflag)
 					break;
 			}
 			if(!Nflag)
 				cout<<"Case #"<<iter<<": YES";
 			
 			//logs
 		}
 		else if ( (N==1) || (N==2) || (M==1) || (M==2) )
 		{
 			cout<<"Case #"<<iter<<": YES";
 		}
 		else if( (N==3) && (M==3) )
 		{
 			if(ptr[1][1] >= ptr[1][0])
 				cout<<"Case #"<<iter<<": YES";
 			else if(ptr[1][1] >= ptr[1][2])
 				cout<<"Case #"<<iter<<": YES";
 			else if(ptr[1][1] >= ptr[0][1])
 				cout<<"Case #"<<iter<<": YES";
 			else if(ptr[1][1] >= ptr[2][1])
 				cout<<"Case #"<<iter<<": YES";
 			else
 				cout<<"Case #"<<iter<<": NO";
 		}
 
 	}
 
 	return 0;
 }
 
 //logs
 			/*
 			for(i=0;i<N;i++)
 			{
 				for(j=0;j<M;j++)
 				{
 					cout<<ptr[i][j]<<" ";
 				}
 				cout<<endl;
 			}
 		
 			for(i=0;i<(N-2);i++)
 			{
 				for(j=0;j<(M-2);j++)
 				{
 					cout<<mover[i][j]<<" ";
 				}
 				cout<<endl;
 			}*/
 			
 //logs
 			/*
 			for(i=0;i<(N);i++)
 			{
 				for(j=0;j<(M);j++)
 				{
 					cout<<mover[i][j]<<" ";
 				}
 				cout<<endl;
 			}*/