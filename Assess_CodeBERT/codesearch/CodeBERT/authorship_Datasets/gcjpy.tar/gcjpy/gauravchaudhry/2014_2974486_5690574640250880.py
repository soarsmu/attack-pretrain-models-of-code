#include<iostream>
 #include <string>
 #include<fstream>
 #include<ostream>
 #include<vector>
 #include<algorithm>
 #include<set>
 #include<deque>
 #include<map>
 #include<math.h>
 using namespace std;
 
 #define InputOutputToFile
 
 #define ROW 50
 #define COL 50
 
 int main(void)
 {
 #ifdef InputOutputToFile
 	
 	//cin redirection
 	std::ifstream fin("cin.txt");
 	std::streambuf *inbuf = std::cin.rdbuf(fin.rdbuf());
 
 	//cout redirection
 	std::streambuf* cout_sbuf = std::cout.rdbuf(); // save original sbuf 
 	std::ofstream   fout("cout.txt"); 
 	std::cout.rdbuf(fout.rdbuf()); // redirect 'cout' to a 'fout' 
 	//std::cout.rdbuf(cout_sbuf); // restore the original stream buffer 
 
 	//cout.txt file using c library
 	//FILE* fp=fopen("C:\\Programming_VS2010\\InterviewStreet\\InsertionSort\\cout.txt","w");
 #endif
 
 	int run = 0;
 	cin>>run;
 	int cs = 1;
 
 	int i=0;
 	int j=0;
 	char board[ROW][COL];
 	for(i=0;i<ROW;i++)
 		for(j=0;j<COL;j++)
 			board[i][j]='.';
 	int row=0;
 	int col=0;
 	int mcount=0;
 	int tmp=0;
 	bool itrFlg = false;
 	while(run--)
 	{
 		if(itrFlg)
 		{
 			row=0;
 			col=0;
 			mcount=0;
 			tmp=0;
 			//reset the board
 			for(i=0;i<ROW;i++)
 				for(j=0;j<COL;j++)
 					board[i][j]='.';
 
 			cout<<endl;
 			//fprintf(fp,"\n");
 		}
 
 		itrFlg = true;
 		cin>>row>>col>>mcount;
 
 		if( mcount==1 && row==2 && col==2)
 		{
 			cout<<"Case #"<<cs<<":"<<endl<<"Impossible";
 		}
 		else if( mcount > ((row-1)*(col-1)+1) )
 		{
 			cout<<"Case #"<<cs<<":"<<endl<<"Impossible";
 		}
 		else
 		{
 			tmp=mcount;
 			for(i=0;i<row;i++)
 			{
 				for(j=0;j<col;j++)
 				{
 					if(tmp>0)
 					{
 						board[i][j]='*';
 						tmp--;
 					}
 					else
 						break;
 				}
 				if(tmp==0)
 					break;
 			}
 			//cout<<"i::"<<i<<" j::"<<j<<endl;
 			if(j<(col-1))
 				board[i][j]='c';
 			else if(i<(row-1))
 				board[i+1][0]='c';
 			//print the board
 			cout<<"Case #"<<cs<<":"<<endl;
 			for(i=0;i<row;i++)
 			{
 				for(j=0;j<col;j++)
 				{
 					cout<<board[i][j];
 				}
 				if( i < (row-1))
 					cout<<endl;
 			}
 		}
 		
 		cs++;
 	}
 
 	return 0;
 }